package com.example.trabalho_api.controller;

import com.example.trabalho_api.model.Tarefa;
import com.example.trabalho_api.repository.TarefaRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tarefas")
public class TarefaController {

    private final TarefaRepository tarefaRepository;

    public TarefaController(TarefaRepository tarefaRepository) {
        this.tarefaRepository = tarefaRepository;
    }

    @PostMapping
    public Tarefa criarTarefa(@Valid @RequestBody Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    @GetMapping
    public List<Tarefa> listarTarefas() {
        return tarefaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Tarefa> buscarTarefa(@PathVariable Long id) {
        Optional<Tarefa> tarefa = tarefaRepository.findById(id);
        return tarefa.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> atualizarTarefa(@PathVariable Long id, @Valid @RequestBody Tarefa tarefaDetalhes) {
        return tarefaRepository.findById(id).map(tarefa -> {
            if (tarefa.isFinalizado()) {
                return ResponseEntity.badRequest().build();
            }
            tarefa.setTitulo(tarefaDetalhes.getTitulo());
            tarefa.setDescricao(tarefaDetalhes.getDescricao());
            tarefa.setDataPrevistaFinalizacao(tarefaDetalhes.getDataPrevistaFinalizacao());
            return ResponseEntity.ok(tarefaRepository.save(tarefa));
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/nao-finalizadas")
    public List<Tarefa> listarTarefasNaoFinalizadas() {
        return tarefaRepository.findByFinalizado(false);
    }

    @GetMapping("/finalizadas")
    public List<Tarefa> listarTarefasFinalizadas() {
        return tarefaRepository.findByFinalizado(true);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deletarTarefa(@PathVariable Long id) {
        return tarefaRepository.findById(id).map(tarefa -> {
            if (tarefa.isFinalizado()) {
                return ResponseEntity.badRequest().build();
            }
            tarefaRepository.delete(tarefa);
            return ResponseEntity.noContent().build();
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }


    @GetMapping("/atrasadas")
    public List<Tarefa> listarTarefasAtrasadas() {
        return tarefaRepository.findByFinalizadoFalseAndDataPrevistaFinalizacaoBefore(LocalDate.now());
    }

    @GetMapping("/entre-datas")
    public List<Tarefa> listarTarefasNaoFinalizadasEntreDatas(
            @RequestParam("inicio") LocalDate inicio,
            @RequestParam("fim") LocalDate fim) {
        return tarefaRepository.findByFinalizadoFalseAndDataPrevistaFinalizacaoBetween(inicio, fim);
    }

    @PutMapping("/finalizar/{id}")
    public ResponseEntity<?> finalizarTarefa(@PathVariable Long id) {
        return tarefaRepository.findById(id).map(tarefa -> {
            if (tarefa.isFinalizado()) {
                return ResponseEntity.badRequest().build();
            }
            tarefa.setFinalizado(true);
            tarefa.setDataFinalizacao(LocalDate.now());
            return ResponseEntity.ok(tarefaRepository.save(tarefa));
        }).orElseGet(() -> ResponseEntity.notFound().build());
    }
}
