package com.example.trabalho_api.repository;

import com.example.trabalho_api.model.Tarefa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TarefaRepository extends JpaRepository<Tarefa, Long> {

    // Métodos personalizados para buscar tarefas por status
    List<Tarefa> findByFinalizado(boolean finalizado);

    // Buscar tarefas não finalizadas e atrasadas
    List<Tarefa> findByFinalizadoFalseAndDataPrevistaFinalizacaoBefore(LocalDate date);

    // Buscar tarefas não finalizadas entre duas datas
    List<Tarefa> findByFinalizadoFalseAndDataPrevistaFinalizacaoBetween(LocalDate start, LocalDate end);
}
